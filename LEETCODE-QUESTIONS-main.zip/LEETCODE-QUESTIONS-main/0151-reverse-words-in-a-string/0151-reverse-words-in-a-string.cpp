//https://leetcode.com/problems/reverse-words-in-a-string/discuss/1531693/C%2B%2B-2-solutions-O(1)-space-Picture-explain-Clean-and-Concise
class Solution {
public:
    string reverseWords(string s) {
        
        reverse(s.begin(), s.end());
        
        int l = 0, r = 0, i = 0, n = s.size();
        
        while (i < n) {
            
            while (i < n && s[i] != ' ')
                s[r++] = s[i++];

            if (l < r) { // if we can find a non-empty word then
                reverse(s.begin() + l, s.begin() + r); // reverse current word
                
                if (r == n) break;
                s[r++] = ' '; // set empty space
                l = r;
            }
            
            ++i; // now i == n or s[i] == ' ', so we skip that character!
        }
        if (r > 0 && s[r-1] == ' ') --r; // skip last empty character if have
        
        s.resize(r);
        
        return s;
    }
};