We can find the number of moves required as moves=\sum_{i=0}^{n-1} a[i] - min(a)*nmoves=∑
i=0
n−1
•
a[i]−min(a)∗n, where nn is the length of the array.